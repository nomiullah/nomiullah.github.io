<?php
/**
 * Template for frontpage
 *
 * @since 1.0
 */

    get_header();
?>
<article class="container">

    <div id="content">

        <!-- / .breadcrumbs -->
        <span style="margin:25px;">
            <a href="http://www.dialmycalls.com/index.html">Home</a> &gt;
            <a href="http://www.dialmycalls.com/features.html">Features</a> &gt; 2-Way Text Messaging
        </span>
        <!-- / .end breadcrumbs -->

        <div class="container-fluid">

            <div class="row-fluid">
                <div style="margin-top:19px;" class="span3">
                    <aside id="sidebar">
                        <div class="widget ctas">
                            <p>
                                <a class="btn orange" href="http://www.dialmycalls.com/signup.html">
                                    <strong>Try It Free</strong> Try Sending A Broadcast Right Now!</a>
                            </p>
                            <p>
                                <a class="btn" href="two-way-text-messaging.html#" data-toggle="modal" data-target="#modal-request-quote">
                                    <strong>Get Pricing</strong> Custom Quote For Your Organization</a>
                            </p>
                        </div>

                        <div class="modal hide fade" id="modal-request-quote">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header icon">
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                        <h2>Request Special Pricing</h2>
                                    </div>
                                    <div class="modal-body">
                                        <p>
                                            We can create a custom pricing plan to meet your organizations needs. We're almost always able to meet or beat anyone's pricing.
                                            Fill out the form below for our best deal, for immediate sales assistance call
                                            us right now at 1-800-928-2086.
                                        </p>

                                        <hr />

                                        <form action="http://www.dialmycalls.com/ajax/request-quote.php" method="post" id="form-request-quote" class="mb0">
                                            <input type="hidden" name="id" value="featurestwo-way-text-messaging" />
                                            <div class="row-fluid">
                                                <div class="span5">
                                                    <label for="request-quote-firstname">Your First Name:</label>
                                                    <input type="text" class="input-block-level" name="firstname" id="request-quote-firstname" maxlength="50" required />
                                                </div>
                                                <div class="span5">
                                                    <label for="request-quote-lastname">Your Last Name:</label>
                                                    <input type="text" class="input-block-level" name="lastname" id="request-quote-lastname" maxlength="50" required />
                                                </div>
                                            </div>
                                            <div class="row-fluid">
                                                <div class="span5">
                                                    <label for="request-quote-email">Your Email Address:</label>
                                                    <input type="email" class="input-block-level" name="email" id="request-quote-email" maxlength="100" required />
                                                </div>
                                                <div class="span5">
                                                    <label for="request-quote-phonenumber">Your Phone Number:</label>
                                                    <input type="tel" class="input-block-level" name="phonenumber" id="request-quote-phonenumber" maxlength="14" alt="phone-us"
                                                        required />
                                                </div>
                                            </div>
                                            <div class="row-fluid">
                                                <div class="span5">
                                                    <label for="request-quote-orgtype">Organization Type:</label>
                                                    <select name="orgtype" id="request-quote-orgtype" class="input-block-level" required>
                                                        <option value=""></option>
                                                        <option value="Business">Business</option>
                                                        <option value="Emergency Management">Emergency Management</option>
                                                        <option value="Employee Alerts">Employee Alerts</option>
                                                        <option value="Government Agency">Government Agency</option>
                                                        <option value="Healthcare">Healthcare</option>
                                                        <option value="Non-Profit">Non-Profit</option>
                                                        <option value="Other">Other</option>
                                                        <option value="Personal Use">Personal Use</option>
                                                        <option value="Political">Political</option>
                                                        <option value="Property Management">Property Management</option>
                                                        <option value="Religious Organizations">Religious Organizations</option>
                                                        <option value="Schools">Schools</option>
                                                        <option value="Sports">Sports</option>
                                                        <option value="Staffing Agency">Staffing Agency</option>
                                                        <option value="Utility Company">Utility Company</option>
                                                    </select>
                                                </div>
                                                <div class="span5">
                                                    <label for="request-quote-recipients">How Many Recipients (approx):</label>
                                                    <select name="recipients" id="request-quote-recipients" class="input-block-level" required>
                                                        <option value=""></option>
                                                        <option value="1 - 100">1 - 100</option>
                                                        <option value="100 - 1,000">100 - 1,000</option>
                                                        <option value="1,000 - 10,000">1,000 - 10,000</option>
                                                        <option value="10,000 - 50,000">10,000 - 50,000</option>
                                                        <option value="50,000 - 100,000">50,000 - 100,000</option>
                                                        <option value="100,000+">100,000+</option>
                                                    </select>
                                                </div>
                                            </div>

                                            <hr />

                                            <button type="submit" class="btn-large">Get Pricing</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>



                        <div class="widget help">
                            <h3>What Features Do We Offer?</h3>
                            <span style="font-weight: bold;">General DialMyCalls Features:</span>
                            <ul style="margin-top:10px !important; margin-bottom: 20px !important;">
                                <li>
                                    <a href="access-control-system.html">Access Control System</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/customer-support.html">Customer Support</a>
                                </li>
                                <li>
                                    <a href="ways-to-access-dialmycalls.html">How To Access DialMyCalls</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/billing-options.html">Payment Methods</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/dialmycalls-trial-version.html">Try Before You Buy</a>
                                </li>
                            </ul>
                            <span style="font-weight: bold;">Account Features:</span>
                            <ul style="margin-top:10px !important; margin-bottom: 20px !important;">
                                <li>
                                    <a href="http://www.dialmycalls.com/features/calling-texting-api.html">API For Developers</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/detailed-broadcast-reports.html">Broadcast Reports</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/contact-management.html">Contact Management</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/do-not-contact-list.html">Do Not Contact List</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/import-contacts.html">Import Contacts</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/mobile-app.html">Mobile App</a>
                                </li>
                            </ul>
                            <span style="font-weight: bold;">Calling Features:</span>
                            <ul style="margin-top:10px !important; margin-bottom: 20px !important;">
                                <li>
                                    <a href="http://www.dialmycalls.com/features/accurateamd-answering-machine-detection.html">Answering Machine Detection</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/custom-caller-id-display.html">Control The Caller ID</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/push-to-leave-message.html">Push To Leave A Message</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/push-to-opt-out.html">Push To Opt-Out</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/push-to-repeat.html">Push To Repeat</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/push-to-talk.html">Push To Talk</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/ways-to-record-messages.html">Recording Messages</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/live-answer-voicemail-messages.html">Send Messages To Voicemails</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/telephone-polls.html">Telephone Polls</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/text-to-speech-recordings.html">Text-To-Speech (T2S)</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/vanity-phone-numbers.html">Vanity Phone Numbers</a>
                                </li>
                            </ul>
                            <span style="font-weight: bold;">Texting (SMS) Features:</span>
                            <ul style="margin-top:10px !important; margin-bottom: 20px !important;">
                                <li>
                                    <a href="two-way-text-messaging.html">2-Way Text Messaging</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/long-code-sms.html">Long Code SMS</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/send-images-via-bulk-sms-text-message.html">Send Images Via Bulk SMS Text Message</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/sms-keywords.html">SMS Keywords</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/sms-text-message-templates.html">SMS Text Message Templates</a>
                                </li>
                            </ul>
                            <span style="font-weight: bold;">Additional Features:</span>
                            <ul style="margin-top:10px !important; margin-bottom: 20px !important;">
                                <li>
                                    <a href="http://www.dialmycalls.com/features/email-broadcasting.html">Emailing Your Message</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/embeddable-widgets.html">Embeddable Widgets</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/mass-notification-portal.html">Mass Notification Portal</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/social-message-sharing.html">Share Your Message Online</a>
                                </li>
                            </ul>
                            <span style="font-weight: bold;">Integrations:</span>
                            <ul style="margin-top:10px !important; margin-bottom: 20px !important;">
                                <li>
                                    <a href="http://www.dialmycalls.com/features/aweber-integration.html">AWeber Integration</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/constant-contact-integration.html">Constant Contact Integration</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/mailchimp-integration.html">MailChimp Integration</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/slack-integration.html">Slack Integration</a>
                                </li>
                                <li>
                                    <a href="http://www.dialmycalls.com/features/zapier-integration.html">Zapier Integration</a>
                                </li>
                            </ul>
                        </div>
                        <div class="widget info">

                            <p>Have Questions? Call Us!
                                <span>1-800-928-2086</span>
                            </p>

                        </div>

                    </aside>

                </div>

                <div class="span9">

                    <section id="main">

                        <div class="hentry page">

                            <div class="the-content">

                                <h1 style="font-size:23px !important; margin-top:15px;">Text Message Replies with 2-Way Text Messaging</h1>
                                <p>Customers that utilize our texting service have the ability to ask a question via text message
                                    and read any reply that their recipients send back. In order to see a text message reply,
                                    you must activate the 2-Way Text Messaging feature.</p>

                                <div align="center">

                                    <figure style="border-color:#E2E1E1 !important; float:none; width:740px; margin-bottom:20px !important;" class="wp-caption alignleft"
                                        id="attachment_214">

                                        <a href="http://www.dialmycalls.com/features/img/business-sms-two-way-texting-chat.png" class="fancy_img">
                                            <img src="http://www.dialmycalls.com/features/img/business-sms-two-way-texting-chat.png" width="740">
                                        </a>

                                        <p style="background: none; background: #E2E1E1 !important; font-family: Arial, Helvetica, sans-serif !important; line-height:12px; text-shadow: none !important; color:#000 !important; font-size: 12px !important; padding:10px !important; position:static !important; min-height:inherit !important"
                                            class="wp-caption-text">Above Image: Instantly reply to text messages sent to your long code SMS number with
                                            our two-way texting feature.
                                            <a href="http://www.dialmycalls.com/features/img/business-sms-two-way-texting-chat.png" class="fancy_img">
                                                <i style="float: right;">
                                                    <img width="13" src="http://www.dialmycalls.com/images/icon-expand.png">
                                                </i>
                                            </a>
                                        </p>


                                    </figure>
                                </div>
                                <p>Activating 2-Way Text Messaging can be done at any time by signing into your account - this
                                    feature costs $19.99 per month (billed every 30 days). Incoming text messages are included
                                    in the initial cost along with 450 SMS replies - a DialMyCalls customer is able to respond
                                    to a reply from the threaded 2-way texting chat window --- outbound texts will utilize
                                    your SMS replies.</p>
                                <h2>Two-Way Text Messaging Pricing Breakdown</h2>
                                <ul>
                                    <li>
                                        <strong>Monthly Fee</strong>:
                                        <em>$19.99 every 30 days</em>
                                    </li>
                                    <li>
                                        <strong>Free Inbound Messages</strong>
                                    </li>
                                    <li>
                                        <strong>Texts Included</strong>:
                                        <em>450 SMS Replies</em>
                                    </li>
                                    <li>
                                        <strong>Additional SMS Replies</strong>:
                                        <em>4.5/c per message</em>
                                    </li>
                                </ul>
                                <p>
                                    <em>(Pricing Displayed Includes One (1) Long Code SMS Local Vanity Number and Two-Way Texting)
                                    </em>
                                </p>
                                <p>Currently our text broadcasting as well as the two-way text messaging service is only available
                                    in the United States - voice broadcasting is available in the United States and Canada.</p>
                                <p>If you have any additional questions regarding DialMyCalls' 2-Way Text Messaging service,
                                    please
                                    <a href="http://www.dialmycalls.com/contactus.html">contact us</a>.</p>

                            </div>
                            <!-- / .the-content -->

                        </div>
                        <!-- / .hentry page -->

                        <section id="call-to">
                            <p style="padding-top:20px;">Create An Account Today And See Why 1,000s Of People Rely On Us</p>
                            <p class="button">
                                <a href="http://www.dialmycalls.com/signup.html">Try Out DialMyCalls Now For Free</a>
                            </p>

                        </section>
                    </section>
                    <!-- #main -->

                </div>

            </div>

        </div>
        <!-- container-fluid -->


    </div>
    <!-- .content -->

</article>
<!-- .container -->

<?php get_footer(); ?>
