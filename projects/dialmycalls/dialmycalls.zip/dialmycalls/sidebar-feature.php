<div style="margin-top:19px;" class="span3">
    <aside id="sidebar">
        <?php
            if ( is_active_sidebar( 'feature-left' ) ) {
                dynamic_sidebar( 'feature-left' );
            }
        ?>
    </aside>
</div>
