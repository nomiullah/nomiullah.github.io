<?php
/*
    Template Name: Composer
*/

get_header();

dmc_render_flexible_rows();

get_footer();
