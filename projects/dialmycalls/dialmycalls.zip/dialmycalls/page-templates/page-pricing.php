<?php
/*
    Template Name: Pricing
*/

get_header();
?>
<div class="main_content">
    <div class="afford_main">
        <div class="container">
            <div class="row">
                <div class="afford">
                    <div class="afford_head">
                        <h2>Affordable Pricing Plans</h2>

                        <p>
                            Find the right plan for your business, or test it out for free.
                        </p>
                    </div>

                    <div class="pay_main">
                        <div class="payblock">
                            <div class="paymounth">
                                <h2>Monthly Plans</h2>

                                <div class="tabbs">
                                    <div class="tab_nav">
                                        <ul>
                                            <li data-tab-link="tab-monthly" class="active" data-title="Monthly Plans">
                                                <span>Monthly</span>
                                            </li>

                                            <li data-tab-link="tab-credits" data-title="Pay As You Go" class="">
                                                <span>Pay As You Go</span>
                                            </li>
                                        </ul>

                                        <div class="clear"></div>
                                    </div>

                                    <div class="tab_con">

                                        <div class="content" data-tab="tab-monthly" style="display: block;">
                                            <div class="afford_cnt">
                                                <div class="perfect">
                                                    <h3>
                                                        <sup>
                                                            <em>From</em>
                                                        </sup>
                                                        $7.49
                                                        <sub> for 25/ month</sub>
                                                    </h3>

                                                    <p>Perfect if you call &amp; text
                                                        <br> the same group of phone numbers. Save money with no strings
                                                        attached - there is no contract, you can cancel any time.</p>
                                                </div>

                                                <div class="contract">
                                                    <ul>
                                                        <li>
                                                            <p>No contract! Upgrade, downgrade,
                                                                <br> or cancel the plan at any time.</p>
                                                        </li>
                                                        <li>
                                                            <p>Send calls and/or text messages;
                                                                <br> e-mail included for free.</p>
                                                        </li>
                                                        <li>
                                                            <p>Calls up to 2 minutes in length;
                                                                <br> all premium options included.</p>
                                                        </li>
                                                    </ul>
                                                </div>

                                                <div class="view_moun">
                                                    <a class="btn" data-tab-link="tab-monthly-info">View monthly plans</a>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="content" data-tab="tab-monthly-info" style="display: none;">
                                            <form action="http://705de4b2.ngrok.io/signuporder.html" method="post">
                                                <input type="hidden" name="packagetype" value="3">

                                                <div class="afford_cnt">
                                                    <div class="contract info">
                                                        <table class="table table-hover">
                                                            <thead>
                                                                <tr>
                                                                    <th># Users</th>
                                                                    <th>Cost Per User</th>
                                                                    <th>Cost Per Month</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="2"> 25 </td>
                                                                    <td>30¢</td>
                                                                    <td>$7.49</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="4"> 50 </td>
                                                                    <td>30¢</td>
                                                                    <td>$14.99</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="6"> 100 </td>
                                                                    <td>35¢</td>
                                                                    <td>$34.99</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="8"> 200 </td>
                                                                    <td>27.5¢</td>
                                                                    <td>$54.99</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="10"> 300 </td>
                                                                    <td>25¢</td>
                                                                    <td>$74.99</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="12"> 400 </td>
                                                                    <td>21¢</td>
                                                                    <td>$84.99</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="14"> 500 </td>
                                                                    <td>19¢</td>
                                                                    <td>$94.99</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="16"> 600 </td>
                                                                    <td>17.5¢</td>
                                                                    <td>$104.99</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="18"> 700 </td>
                                                                    <td>16.5¢</td>
                                                                    <td>$114.99</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="20"> 900 </td>
                                                                    <td>16¢</td>
                                                                    <td>$144.99</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="22"> 1,400 </td>
                                                                    <td>15¢</td>
                                                                    <td>$210.99</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="24"> 2,000 </td>
                                                                    <td>14¢</td>
                                                                    <td>$280.99</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="32"> 3,000 </td>
                                                                    <td>13¢</td>
                                                                    <td>$390.00</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="34"> 4,000 </td>
                                                                    <td>13¢</td>
                                                                    <td>$520.00</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="41"> 6,000 </td>
                                                                    <td>12¢</td>
                                                                    <td>$715.00</td>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="4">
                                                                        Larger Customer?
                                                                        <a href="http://705de4b2.ngrok.io/volumepricing.html">Check Our Volume Pricing</a>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>

                                                    <div class="view_moun">
                                                        <a class="back" data-tab-link="tab-monthly">Back</a>
                                                        <button class="btn">Buy Now</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>


                                        <div class="content" data-tab="tab-credits" style="display: none;">
                                            <div class="afford_cnt">
                                                <div class="perfect">
                                                    <h3>
                                                        <sup>
                                                            <em>From</em>
                                                        </sup>
                                                        $10.00
                                                        <sub> for 140 credits</sub>
                                                    </h3>

                                                    <p>Perfect for companies who call &amp; text the same group of phone
                                                        numbers. Save money with no strings attached - there is no contract,
                                                        you can cancel any time.</p>
                                                </div>

                                                <div class="contract">
                                                    <ul>
                                                        <li>
                                                            <p>Credits are purchased in advance.
                                                                <br> There are no monthly fees and the credits never expire.</p>
                                                        </li>
                                                        <li>
                                                            <p>1 Credit = 1 30-Second Call to 1 Number or 1 Text Message.</p>
                                                        </li>
                                                        <li>
                                                            <p>For example: to send a 30 second message to 30 people it
                                                                would be 30 credits. (Each 30 second increment costs
                                                                1 credit per contact)</p>
                                                        </li>
                                                    </ul>
                                                </div>

                                                <div class="view_moun">
                                                    <a class="btn active" data-tab-link="tab-credits-info">View credit packages</a>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="content" data-tab="tab-credits-info" style="display: none;">
                                            <form action="http://705de4b2.ngrok.io/signuporder.html" method="post">
                                                <input type="hidden" name="packagetype" value="1">

                                                <div class="afford_cnt">
                                                    <div class="contract info">
                                                        <table class="table table-hover">
                                                            <thead>
                                                                <tr>
                                                                    <th># Credits</th>
                                                                    <th>Cost Per Credit</th>
                                                                    <th>Total Cost</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="1"> 140 </td>
                                                                    <td>7¢</td>
                                                                    <td>$10.00</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="2"> 380 </td>
                                                                    <td>6.5¢</td>
                                                                    <td>$25.00</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="3"> 825 </td>
                                                                    <td>6¢</td>
                                                                    <td>$50.00</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="4"> 1,800 </td>
                                                                    <td>5.5¢</td>
                                                                    <td>$100.00</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="5"> 5,000 </td>
                                                                    <td>5¢</td>
                                                                    <td>$250.00</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="6"> 11,100 </td>
                                                                    <td>4.5¢</td>
                                                                    <td>$500.00</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="7"> 25,000 </td>
                                                                    <td>4¢</td>
                                                                    <td>$999.99</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="8"> 50,000 </td>
                                                                    <td>4¢</td>
                                                                    <td>$1875.00</td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <input type="radio" name="packageid" value="9"> 100,000 </td>
                                                                    <td>3.5¢</td>
                                                                    <td>$3500.00</td>
                                                                </tr>
                                                                <tr>
                                                                    <td colspan="4">
                                                                        Larger Customer?
                                                                        <a href="http://705de4b2.ngrok.io/volumepricing.html">Check Our Volume Pricing</a>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>

                                                    <div class="view_moun">
                                                        <a class="back" data-tab-link="tab-credits">Back</a>
                                                        <button class="btn">Buy Now</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="tailored_block">
                            <div class="tailored">
                                <div class="tail_price">
                                    <h4>Tailored pricing</h4>

                                    <figure>
                                        <img src="images/tailored.png" alt="tailored">
                                    </figure>

                                    <p>
                                        Let us create the perfect package to
                                        <br> suit your business needs. We can create annual plans to make budgeting easier,
                                        and offer bulk pricing.
                                    </p>
                                </div>

                                <div class="contract contract1">
                                    <ul>
                                        <li>
                                            <p>Perfect for customers who need plans based on per member or unit pricing
                                            </p>
                                        </li>
                                        <li>
                                            <p>Anual plans for organizations who need to make budgeting easier</p>
                                        </li>
                                        <li>
                                            <p>Pricing that will span across multiple accounts for your organisation</p>
                                        </li>
                                        <li class="last">
                                            <p>Bulk pricing for larger organisations that use higher volume</p>
                                        </li>
                                    </ul>
                                </div>

                                <div class="view_moun view_moun1">
                                    <a class="btn" href="tel:18009282086">Call us at 1-800-928-2086</a>
                                </div>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="plans_main">
        <div class="container-fluid">
            <div class="row">
                <div class="plans_block">
                    <div class="plans_view col-sm-5"></div>

                    <div class="best_plans best_plans1 col-sm-7">
                        <div class="messaging">
                            <h3>Try the new 2-way messaging</h3>

                            <p>
                                Activate 2-way texting on your account today and unleash the power of our text messaging. Works with both our short code
                                and vanity phone numbers!
                            </p>

                            <ul>
                                <li>
                                    <p>Free unlimited incoming messages</p>
                                </li>
                                <li>
                                    <p>Free local phone number</p>
                                </li>
                                <li>
                                    <p>450 outgoing messages per month</p>
                                </li>
                                <li>
                                    <p>Works on website and mobile apps</p>
                                </li>
                            </ul>

                            <a href="http://705de4b2.ngrok.io/2-way-sms">Get pricing</a>
                        </div>
                    </div>

                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="upgrade_main">
        <div class="container">
            <div class="row">
                <div class="upgrade col-sm-7">
                    <h2>Want To Try Before You Buy?</h2>

                    <p>
                        Sign up for a free account and get one call with a 30 second message to up to 25 contacts per week at absolutely no cost;
                        no credit card or payment is required! Our free service is great to try out DialMyCalls or for
                        small organizations. Once you're a member you can upgrade to use credits or a monthly plan at
                        anytime.
                    </p>

                    <a href="http://705de4b2.ngrok.io/signup.html">Try it for free</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
get_footer();
