<?php
/**
 * The main template file
 *
 * @since 1.0
 */

    get_header();
?>
    <div class="container">
        <div class="top-content">
            <h1>Coworking space. Community. Collective.</h1>
            <div class="social-icons">
                <ul>
                    <li>
                        <a href="#" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/facebook.svg" alt="" title="">
                        </a>
                    </li>
                    <li>
                        <a href="#" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/instagram.svg" alt="" title="">
                        </a>
                    </li>
                    <li>
                        <a href="#" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/twitter.svg" alt="" title="">
                        </a>
                    </li>
                </ul>
            </div>
            <div class="clear"></div>
            <p>Membership based co–op connecting work, leisure & culture</p>
        </div>
        <div class="about-thumbnail">
            <img src="<?php echo get_template_directory_uri(); ?>/assets/images/we-work-pasadena.jpg" alt="" title="">
        </div>
    </div>
    <div class="about-content">
        <div class="container">
            <div class="about-detail">
                <strong>About KIN</strong>
                <h2>A membership-based collective and working space. Welcome to the family.</h2>
                <p>Catching up over that first —or fifth— cup of coffee; going to the “the usual” for lunch; bouncing ideas off someone who isn’t Mom. For creatives and creators, a working space goes beyond big windows, brick walls and boardrooms. We can get that anywhere. What we need is human connection and to be part of a crew. </p>
            </div>
        </div>
    </div>
    <div class="full-image">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/full-image.jpg" alt="" title="">
    </div>
    <div class="full-white-content">
        <div class="container">
            <h2>Coworking is a family affair.</h2>
            <p>KIN is about the people. We are more than just a working space — we have built a community, collective and culture, and it’s baked into our DNA. The word KIN means ‘a family relationship’ and that is how we view our membership. A space where you can be yourself, do what you live to do and be supported by a group of likeminded freelancers, entrepreneurs and innovators. And yeah, we have the windows and brick too.</p>
        </div>
    </div>
    <div class="full-grey-content">
        <div class="container">
            <h3>Tired of being an only child?</h3>
            <p>Drop KIN a line and join the family.</p>
            <a href="#" class="black-btn">Contact us</a>
        </div>
    </div>
<?php get_footer(); ?>