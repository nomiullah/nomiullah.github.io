<div class="upgrade_main">
    <div class="container">
        <div class="row">
            <div class="upgrade col-sm-7">
                <?php the_sub_field( 'content' ); ?>
            </div>
        </div>
    </div>
</div>
