<div class="afford_main">
    <div class="container">
        <div class="row">
            <div class="afford <?php echo get_sub_field( 'show_plans_panel' ) ? 'has-plans-panel' : ''; ?> <?php echo get_sub_field( 'show_tailored_panel' ) ? 'has-tailored-panel' : ''; ?>">
                <div class="afford_head">
                    <?php dmc_the_field( 'heading', '<h2>', '</h2>', true ); ?>
                    <?php dmc_the_field( 'subheading', '<p>', '</p>', true ); ?>
                </div>

                <div class="pay_main">
                    <?php
                        $plans = get_sub_field( 'plans' );
                        if ( get_sub_field( 'show_plans_panel' ) && count ( $plans ) ) :
                    ?>
                    <div class="payblock">
                        <div class="paymounth">
                            <h2><?php echo $plans[0]['title']; ?></h2>

                            <div class="tabbs">
                                <div class="tab_nav">
                                    <ul>
                                        <?php foreach( $plans as $index => $plan ) : ?>
                                        <li data-tab-link="tab-<?php echo sanitize_title( $plan['title'] ); ?>" <?php echo $index == 0 ? 'class="active"' : ''; ?> data-title="<?php echo $plan['title']; ?>">
                                            <span><?php echo $plan['tab_text']; ?></span>
                                        </li>
                                        <?php endforeach; ?>
                                        <div class="clear"></div>
                                    </ul>
                                </div>

                                <div class="tab_con">

                                    <?php foreach( $plans as $index => $plan ) : ?>
                                    <div class="content" data-tab="tab-<?php echo sanitize_title( $plan['title'] ); ?>" <?php echo $index == 0 ? 'style="display: block;"' : ''; ?>>
                                        <div class="afford_cnt">
                                            <div class="perfect">
                                                <h3>
                                                    <sup><em>From</em></sup>
                                                    $<?php echo $plan['price']; ?>
                                                    <sub> <?php echo $plan['subtext']; ?></sub>
                                                </h3>

                                                <?php echo $plan['description']; ?>
                                            </div>

                                            <?php if( count( $plan['features'] ) ) : ?>
                                            <div class="contract">
                                                <ul>
                                                    <?php foreach( $plan['features'] as $feature ) : ?>
                                                    <li><p><?php echo $feature['feature']; ?></p></li>
                                                    <?php endforeach; ?>
                                                </ul>
                                            </div>
                                            <?php endif; ?>

                                            <div class="view_moun">
                                                <?php if ( $plan['button_type'] == 'link' ) : ?>
                                                <a href="<?php echo $plan['button_link']['url']; ?>" target="<?php echo $plan['button_link']['target']; ?>" class="btn"><?php echo $plan['button_link']['title']; ?></a>
                                                <?php else : ?>
                                                <a class="btn" data-tab-link="tab-<?php echo sanitize_title( $plan['title'] ); ?>-info"><?php echo $plan['toggle_button_text']; ?></a>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="content" data-tab="tab-<?php echo sanitize_title( $plan['title'] ); ?>-info" style="display: none;">
                                        <form action="<?php echo $plan['signup_link']; ?>" method="post">
                                            <input type="hidden" name="packagetype" value="<?php echo $plan['package_type']; ?>">

                                            <div class="afford_cnt">
                                                <div class="contract info">
                                                    <table class="table table-hover">
                                                        <thead>
                                                            <tr>
                                                                <th><?php echo $plan['package_columns'][0]['column1']; ?></th>
                                                                <th><?php echo $plan['package_columns'][0]['column2']; ?></th>
                                                                <th><?php echo $plan['package_columns'][0]['column3']; ?></th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php foreach( $plan['packages'] as $i => $row ) : ?>
                                                                <tr>
                                                                    <td><input type="radio" name="packageid" value="<?php echo $row['id']; ?>"> <?php echo $row['column1']; ?> </td>
                                                                    <td><?php echo $row['column2']; ?></td>
                                                                    <td><?php echo $row['column3']; ?></td>
                                                                </tr>
                                                            <?php endforeach; ?>

                                                            <?php if ( ! empty ( $plan['upsell_copy'] ) ) : ?>
                                                                <tr>
                                                                    <td colspan="4"><?php echo str_replace( [ '<p>', '</p>' ], [ '', '' ], $plan['upsell_copy'] ); ?></td>
                                                                </tr>
                                                            <?php endif; ?>
                                                        </tbody>
                                                    </table>
                                                </div>

                                                <div class="view_moun">
                                                    <a class="back" data-tab-link="tab-<?php echo sanitize_title( $plan['title'] ); ?>">Back</a>
                                                    <button class="btn">Buy Now</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if ( get_sub_field( 'show_tailored_panel' ) ) : ?>
                    <div class="tailored_block">
                        <div class="tailored">
                            <div class="tail_price">
                                <?php dmc_the_field( 'tailored_heading', '<h4>', '</h4>', true ); ?>

                                <?php if ( $icon = get_sub_field( 'tailored_icon' ) ) : ?>
                                <figure><img src="<?php echo dmc_get_attachment( $icon, 'large' ); ?>" alt="<?php the_field( 'tailored_heading' ); ?>"></figure>
                                <?php endif; ?>

                                <?php the_sub_field( 'tailored_description' ); ?>
                            </div>

                            <?php if ( have_rows( 'tailored_features' ) ) : ?>
                            <div class="contract contract1">
                                <ul>
                                    <?php while ( have_rows( 'tailored_features' ) ) : the_row( 'tailored_features' ); ?>
                                    <li>
                                        <?php dmc_the_field( 'feature', '<p>', '</p>', true ); ?>
                                    </li>
                                    <?php endwhile; ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                            <?php if ( $button = get_sub_field( 'tailored_button' ) ) : ?>
                            <div class="view_moun view_moun1">
                                <a class="btn" href="<?php echo $button['url']; ?>" target="<?php echo $button['target']; ?>"><?php echo $button['title']; ?></a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </div>
</div>
