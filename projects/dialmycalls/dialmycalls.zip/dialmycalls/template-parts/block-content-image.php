<div class="plans_main">
    <div class="container-fluid">
        <div class="row">
            <div class="plans_block">
                <div class="plans_view col-sm-5" style="background: url(<?php the_sub_field( 'image' ); ?>) no-repeat;"></div>

                <div class="best_plans best_plans1 col-sm-7">
                    <div class="messaging">
                        <?php the_sub_field( 'content' ); ?>
                    </div>
                </div>

                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
