<?php

/* Limit ScrollReveal animation to social icons in Intro Block only */
$sr_element_class = '';
$sr_element_data = '';
if ( isset( $sr_flag ) && $sr_flag == 'enable' ) {
    $sr_element_class = 'sr-element';
    $sr_element_data = 'data-sr-origin="right"';

    set_query_var( 'sr_flag', 'expired' );
}

while ( have_rows( 'social_profiles', 'option' ) ) :
    the_row();

    if ( get_sub_field( 'facebook' ) || get_sub_field( 'instagram' ) || get_sub_field( 'twitter' ) ) :
        ?>
        <div class="social-icons <?php echo $sr_element_class; ?>" <?php echo $sr_element_data; ?>>
            <ul>
                <?php if ( get_sub_field( 'facebook' ) ) : ?>
                <li>
                    <a href="<?php the_sub_field( 'facebook' ) ?>" target="_blank">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/facebook.svg" alt="Facebook" title="Facebook">
                    </a>
                </li>
                <?php endif; ?>

                <?php if ( get_sub_field( 'instagram' ) ) : ?>
                <li>
                    <a href="<?php the_sub_field( 'instagram' ) ?>" target="_blank">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/instagram.svg" alt="Instagram" title="Instagram">
                    </a>
                </li>
                <?php endif; ?>

                <?php if ( get_sub_field( 'twitter' ) ) : ?>
                <li>
                    <a href="<?php the_sub_field( 'twitter' ) ?>" target="_blank">
                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/twitter.svg" alt="Twitter" title="Twitter">
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </div><!-- .social-icons -->
        <?php
    endif;
endwhile;
?>