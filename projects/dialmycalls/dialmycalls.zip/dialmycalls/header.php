<?php
/**
 * The header for our theme
 *
 * @since 1.0
 */
?><!DOCTYPE html>
<!--[if lt IE 7]><html class="ie6 ie" lang="en"><![endif]-->
<!--[if IE 7]><html class="ie7 ie" lang="en"><![endif]-->
<!--[if IE 8]><html class="ie8 ie" lang="en"><![endif]-->
<!--[if IE 9]><html class="ie9 ie" lang="en"><![endif]-->
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="profile" href="http://gmpg.org/xfn/11">

    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?> itemscope itemtype="http://schema.org/WebPage">

    <!-- Header -->
    <header class="dialmycalls-header">
        <div class="top-bar">
            <div class="container">
                <div class="left">
                    <a href="<?php bloginfo( 'url' ); ?>">
                        <?php dmc_get_logo( 'header', true ); ?>
                    </a>
                </div>
                <div class="left">
                    <?php
                        wp_nav_menu( array(
                            'theme_location' => 'header',
                            'walker' => new Header_Desktop_Walker_Nav_Menu(),
                            'container' => 'div',
                            'container_class' => 'links',
                            'items_wrap' => '%3$s'
                        ) );
                    ?>
                </div>

                <div class="right sign-up">
                    <?php if ( $login = get_field( 'header_login_button', 'option' ) ) : ?>
                        <a class="login" href="<?php echo $login['url']; ?>" target="<?php echo $login['target']; ?>">
                            <strong><?php echo $login['title']; ?></strong>
                        </a>
                    <?php endif; ?>

                    <?php if ( $signup = get_field( 'header_signup_button', 'option' ) ) : ?>
                        <a class="signup btn-large" href="<?php echo $signup['url']; ?>" target="<?php echo $signup['target']; ?>"><?php echo $signup['title']; ?></a>
                    <?php endif; ?>
                </div>

                <?php if ( get_field( 'header_cta_phrase', 'option' ) && get_field( 'header_phone_number', 'option' ) ) : ?>
                <div class="right phone">
                    <?php the_field( 'header_cta_phrase', 'option' ); ?>

                    <?php if ( get_field( 'header_phone_number', 'option' ) ) : ?>
                    <span class="phone">&nbsp;<?php the_field( 'company_phone', 'option' ); ?></span>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <header class="fixed">
        <div class="container">
            <div>
                <div class="pull-left">
                    <a href="<?php bloginfo( 'url' ); ?>">
                        <?php dmc_get_logo( 'header', true ); ?>
                    </a>
                </div>
            </div>

            <?php
                wp_nav_menu( array(
                    'theme_location' => 'header',
                    'walker' => new Header_Desktop_Walker_Nav_Menu(),
                    'container' => 'div',
                    'container_class' => 'links',
                    'items_wrap' => '%3$s'
                ) );
            ?>

            <div>
                <?php $has_login = false; ?>
                <?php if ( $login = get_field( 'header_login_button', 'option' ) ) : $has_login = true; ?>
                    <div class="pull-right">
                        <a class="btn-large" href="<?php echo $login['url']; ?>" target="<?php echo $login['target']; ?>">Try it Free</a>
                    </div>
                <?php endif; ?>

                <?php if ( get_field( 'header_cta_phrase', 'option' ) && get_field( 'header_phone_number', 'option' ) ) : ?>

                    <?php if ( $has_login ) : ?>
                    <div class="divider pull-right">|</div>
                    <?php endif; ?>

                    <div class="call pull-right">
                        <?php the_field( 'header_cta_phrase', 'option' ); ?>

                        <?php if ( get_field( 'header_phone_number', 'option' ) ) : ?>
                        <span class="number">&nbsp;<?php the_field( 'company_phone', 'option' ); ?></span>
                        <?php endif; ?>
                    </div>

                <?php endif; ?>
            </div>
        </div>
    </header>

    <header id="navigation">

        <div class="navbar container">

            <div class="navbar-inner">

                <div class="container">

                    <a class="brand" href="../index.html">
                        <span>Dial My Calls</span>You record it, we send it... </a>

                    <span class="mobile-only">Call Us Now: 1-800-928-2086</span>


                    <div class="secondary">

                        <?php if ( get_field( 'header_cta_phrase', 'option' ) && get_field( 'header_phone_number', 'option' ) ) : ?>
                        <p class="phone">
                            <span class="txt"><?php get_field( 'header_cta_phrase', 'option' ); ?></span>

                            <?php if ( get_field( 'header_phone_number', 'option' ) ) : ?>
                            <span class="num">1-800-928-2086</span>&nbsp;<?php the_field( 'company_phone', 'option' ); ?></span>
                            <?php endif; ?>
                        </p>
                        <?php endif; ?>

                        <p class="controls">
                            <a class="btn-large" href="http://www.dialmycalls.com/signup.html">Try It Free</a>
                            <span>Or</span>
                            <a class="btn-large" href="http://www.dialmycalls.com/login.html">Login</a>
                        </p>

                    </div>

                    <a data-target=".nav-collapse" data-toggle="collapse" class="btn btn-navbar">

                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>

                    </a>

                    <div class="nav-collapse collapse navbar-responsive-collapse">

                        <ul class="nav menue">

                            <li>
                                <a href="http://www.dialmycalls.com/howitworks.html">How It Works</a>
                            </li>
                            <li>
                                <a href="http://www.dialmycalls.com/features.html">Features </a>
                            </li>
                            <li>
                                <span class="new">new</span>
                                <a href="http://www.dialmycalls.com/texting.html">Texting</a>
                            </li>
                            <li>
                                <a href="http://www.dialmycalls.com/pricing.html">Pricing</a>
                            </li>
                            <li class="dropdown">
                                <a href="two-way-text-messaging.html#" class="dropdown-toggle" data-toggle="dropdown">
                                    Case Studies
                                    <b class="caret"></b>
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="http://www.dialmycalls.com/school-notification.html">School Notifications</a>
                                    </li>
                                    <li>
                                        <a href="http://www.dialmycalls.com/church-calls.html">Churches &amp; Religious Groups</a>
                                    </li>
                                    <li>
                                        <a href="http://www.dialmycalls.com/emergency-notification.html">Emergency Notifications</a>
                                    </li>
                                    <li>
                                        <a href="http://www.dialmycalls.com/non-profits.html">Non-Profits</a>
                                    </li>
                                    <li>
                                        <a href="http://www.dialmycalls.com/property-management.html">Property Management</a>
                                    </li>
                                    <li>
                                        <a href="http://www.dialmycalls.com/staff-notification-service.html">Staffing &amp; Employees</a>
                                    </li>
                                    <li>
                                        <a href="http://www.dialmycalls.com/team-calls.html">Sports Teams &amp; Leagues</a>
                                    </li>
                                    <li>
                                        <a href="http://www.dialmycalls.com/customer-reminders.html">Customer Notifications</a>
                                    </li>
                                    <li>
                                        <a href="http://www.dialmycalls.com/mass-notification.html">General Mass Notifications</a>
                                    </li>
                                </ul>
                            </li>
                            <li>
                                <a href="../help.html">FAQs & Tutorials </a>
                            </li>
                            <li>
                                <a href="http://www.dialmycalls.com/contactus.html">Contact Us</a>
                            </li>

                        </ul>

                    </div>
                    <!-- / .nav-collapse -->

                </div>

            </div>
            <!-- / .navbar-inner -->

        </div>
        <!-- / .navbar -->

    </header>
