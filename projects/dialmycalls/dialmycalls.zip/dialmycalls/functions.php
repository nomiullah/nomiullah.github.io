<?php
/**
 * DialMyCalls functions and definitions
 *
 * The short keyword "dmc" is used as prefix to function names to make them unique.
 *
 * @since 1.0
 */

/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
function dmc_setup() {

	/* Let WordPress manage the document title. */
	add_theme_support( 'title-tag' );

	/* Allow featured image */
	add_theme_support( 'post-thumbnails' );

	/* Allow HTML5 markup */
	add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption' ) );

	/* Register Navigation Menus */
	register_nav_menus( array(
        'header'   => __( 'Header Menu', 'dmc' ),
        'footer'   => __( 'Footer Menu', 'dmc' ),
        'legal'	   => __( 'Legal Links Menu', 'dmc' ),
        'features' => __( 'Features', 'dmc' ),
    ) );

	/* Custom image sizes */
	// add_image_size( 'thumbnail-features', 833, 556, true );
}
add_action( 'after_setup_theme', 'dmc_setup' );

/**
 * Enqueue scripts and styles
 */
function dmc_scripts() {

	/* Bootstrap */
	wp_enqueue_style( 'bootstrap', '//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css' );

	/* Theme stylesheet */
	// wp_enqueue_style( 'style', get_template_directory_uri() . '/assets/css/style.min.css' );
	wp_enqueue_style( 'style', get_template_directory_uri() . '/assets/css/style.css' );

    wp_enqueue_script( 'html5shiv', '//html5shim.googlecode.com/svn/trunk/html5.js', false, NULL );
	wp_script_add_data( 'html5shiv', 'conditional', 'lt IE 9' );

	/* Load jQuery in footer */
	// wp_deregister_script( 'jquery' );
    // wp_register_script( 'jquery', includes_url( '/js/jquery/jquery.js' ), false, NULL, true );
	// wp_enqueue_script( 'jquery' );

	/* Bootstrap JS */
	wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array( 'jquery' ), NULL, true );

	/* Libraries JS */
	wp_enqueue_script( 'libs', get_template_directory_uri() . '/assets/js/libs.js', array( 'jquery', 'bootstrap' ), NULL, true );

	/* Theme JS */
	wp_enqueue_script( 'theme', get_template_directory_uri() . '/assets/js/theme.js', array( 'jquery' ), NULL, true );
}
add_action( 'wp_enqueue_scripts', 'dmc_scripts' );

/**
 * Inject code to wp_head
 */
function dmc_head_injections() {
	echo "<style>.sr-element { visibility: hidden; }</style>";
}
// add_action( 'wp_head', 'dmc_head_injections', 5 );

/**
 * Removes bloat
 * Meta tags, styles, scripts
 */
function dmc_remove_bloat() {

	/* Remove emoji support */
	remove_action( 'admin_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );
	remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
	remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );

	/* Removes Emoji support from TinyMCE */
	add_filter( 'tiny_mce_plugins', 'dmc_disable_emoji_tinymce' );

	/* Remove WPML generator meta tag */
	global $sitepress;
	remove_action( 'wp_head', array( $sitepress, 'meta_generator_tag' ) );

	/* Other junk */
	remove_action('wp_head', 'rsd_link'); // remove really simple discovery link
	remove_action('wp_head', 'wp_generator'); // remove wordpress version

	remove_action('wp_head', 'feed_links', 2); // remove rss feed links
	remove_action('wp_head', 'feed_links_extra', 3); // removes all extra rss feed links

	remove_action('wp_head', 'index_rel_link'); // remove link to index page
	remove_action('wp_head', 'wlwmanifest_link'); // remove wlwmanifest.xml (needed to support windows live writer)

	remove_action('wp_head', 'start_post_rel_link', 10, 0); // remove random post link
	remove_action('wp_head', 'parent_post_rel_link', 10, 0); // remove parent post link
	remove_action('wp_head', 'adjacent_posts_rel_link', 10, 0); // remove the next and previous post links
	remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0 );

	remove_action('wp_head', 'wp_shortlink_wp_head', 10, 0 );

	remove_action( 'wp_head', 'wp_resource_hints', 2 );

	remove_action( 'xmlrpc_rsd_apis', 'rest_output_rsd' );
	remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
	remove_action( 'template_redirect', 'rest_output_link_header', 11 );
}
add_action( 'init', 'dmc_remove_bloat' );

/**
 * Removes Emoji support form TinyMCE
 *
 * @param  array $plugins Loaded plugins
 * @return array          Plugins list, wpemjoi removeod
 */
function dmc_disable_emoji_tinymce( $plugins ) {
	if ( is_array( $plugins ) ) {
		return array_diff( $plugins, array( 'wpemoji' ) );
	} else {
		return array();
	}
}

/**
 * ACF theme options pages
 */
if ( function_exists('acf_add_options_page') ) {

	acf_add_options_page(array(
		'page_title' 	=> 'Theme General Settings',
		'menu_title'	=> 'Theme Settings',
		'menu_slug' 	=> 'theme-general-settings',
		'capability'	=> 'edit_posts',
		'redirect'		=> false
	));
}

/**
 * Adds SVG support to WP Media
 *
 * @param  array $mimes Supported mime types
 * @return array
 */
function dmc_mime_types( $mimes ) {
  $mimes['svg'] = 'image/svg+xml';

  return $mimes;
}
add_filter('upload_mimes', 'dmc_mime_types');

/**
 * Custom template tags and layout/styling helpers
 */
require get_parent_theme_file_path( '/inc/template-tags.php' );

/**
 * Cusotm post type definions
 */
require get_parent_theme_file_path( '/inc/custom-post-types/init.php' );

/**
 * Custom Walker Nav classes
 */
require get_parent_theme_file_path( '/inc/walker-nav-classes.php' );

/**
 * Theme widget areas
 */
require get_parent_theme_file_path( '/inc/widget-areas.php' );

/**
 * Theme shortcodes
 */
require get_parent_theme_file_path( '/inc/shortcodes.php' );

/**
 * Changes ACF JSON directory
 *
 * @param  string $path Default ACF JSON direcotry
 * @return string
 */
function dmc_acf_json_save_point( $path ) {

    return get_stylesheet_directory() . '/inc/acf-json';
}
add_filter('acf/settings/save_json', 'dmc_acf_json_save_point');

/**
 * Loads ACF JSON
 *
 * @param array $paths ACF JSON directory paths
 * @return array
 */
function dmc_acf_json_load_point( $paths ) {

    unset($paths[0]);
    $paths[] = get_stylesheet_directory() . '/inc/acf-json';;

    return $paths;
}
add_filter('acf/settings/load_json', 'dmc_acf_json_load_point');

/**
 * Enqueue admin specific styles
 */
function dmc_admin_styles() {
	wp_enqueue_style( 'dmc-admin-styles', get_template_directory_uri() . '/assets/css/admin-styles.css' );
}
add_action( 'admin_enqueue_scripts', 'dmc_admin_styles' );

/**
 * Check if ACF Flexible Content has FAQ Block
 *
 * @param int $post_id Post ID to check FAQ Block in
 * @return boolean
 */
function dmc_fc_has_layout( $layout = '', $fields = array(), $post_id = 0 ) {

	if ( !is_array( $fields ) || !count( $fields ) ) {
		return false;
	}

	if ( !$post_id ) {
		$post_id = get_the_ID();
	}

    foreach ( $fields as $field ) {
    	$field_data = get_field( $field, $post_id );

    	if ( $field_data && array_search( $layout, array_column( $field_data, 'acf_fc_layout' ) ) !== false ) {
    		return true;
    	}
    }

    return false;
}

/**
 * Add page specific body classes
 *
 * @param array $classes CSS classes for <body>
 */
function dmc_body_classes( $classes ) {

	if ( $c = get_field( 'body_classes' ) ) {
		$classes[] = $c;
	}

	return $classes;
}
add_filter( 'body_class', 'dmc_body_classes' );


/**
 * Disable srcset output
 */
add_filter( 'max_srcset_image_width', function() { return 1; } );

/**
 * Enable shortcode parsing in text widgets
 */
// add_filter('widget_text','do_shortcode');

function dmc_inject_traffic_tracking() {
	?>
	<script type="text/javascript">
		jQuery(document).ready(function () {
			<?php

			$_SESSION['traffic_tracking'][] = $_SERVER['REQUEST_URI'];

			if (empty($_SESSION['at_run'])) {
				$data_track_arr = [
					'referrer' => $_SERVER['HTTP_REFERER'],
					'get'      => $_GET,
					'post'     => $_POST,
				];

				?>

				$.ajax(
					{
						type    : "POST",
						url     : '/ajax/internalapi/adtrack',
						data    : JSON.stringify(<?= json_encode($data_track_arr) ?>),
						success : function (data) {
						},
						dataType: 'json'
					}
				);
				<?php

				$_SESSION['at_run'] = true;
			}
			?>
		});
	</script>
	<?php
}
add_action( 'wp_footer', 'dmc_inject_traffic_tracking' );
