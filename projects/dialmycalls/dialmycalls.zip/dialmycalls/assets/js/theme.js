jQuery(document).ready(function ($) {
    $body = $('body');

    $(window).scroll(function () {
        var y = $(window).scrollTop();
        if (y > 0) {
            $(".dialmycalls-header .logo").css("height", "30px");
            $(".dialmycalls-header .logo").css("margin-top", "0px");
            $(".dialmycalls-header .logo").css("padding-bottom", "10px");
        }
        if (y == 0) {
            $(".dialmycalls-header .logo").css("height", "40px");
            $(".dialmycalls-header .logo").css("margin-top", "-5px");
            $(".dialmycalls-header .logo").css("padding-bottom", "5px");
        }
        if ($(window).width() < 767) {
            if (y > 200) {
                $("header.fixed").fadeIn("slow");
            } else {
                $('header.fixed').fadeOut('slow');
            }
        }
    });

    $(function () {
        $('input[name="phonenumber"]', '#form-sample-call').setMask();
        $('input[name="phonenumber"]', '#form-request-quote').setMask();

        $('#form-sample-call').ajaxForm({
            dataType: 'json',
            success: function (response) {
                if (response['result'] == 'ok') {
                    $('.modal-body', '#modal-sample-call')
                        .html(
                            'Thank you! You should receive your sample call shortly.'
                        );
                } else {
                    var msg = 'The following errors occurred:';
                    $.each(response['errors'], function (key, value) {
                        msg += '\n- ' + value;
                    });
                    alert(msg);
                }
            }
        });

        $('#form-request-quote').ajaxForm({
            dataType: 'json',
            success: function (response) {
                if (response['result'] == 'ok') {
                    $('.modal-body', '#modal-request-quote')
                        .html(
                            'Thank you! Someone on our team will get back to you shortly with custom pricing information.'
                        );
                } else {
                    var msg = 'The following errors occurred:';
                    $.each(response['errors'], function (key, value) {
                        msg += '\n- ' + value;
                    });
                    alert(msg);
                }
            }
        });
    });

    $("a.fancy_img").fancybox({
        'titleShow': false
    });

    $('.dropdown-toggle').on('click', function(evt) {
        evt.stopPropagation();
    });

    var $tabTitle = $('.paymounth > h2');
    var $tabs = {};

    $('.tabbs [data-tab-link]').click(function () {
        var $curr = $(this);

        // Show new title (if any).
        var title = $curr.data('title');

        if (title !== null) {
            $tabTitle.html(title);
        }

        // Mark others inactive, this one active.
        $curr.addClass('active');
        $curr.siblings().removeClass('active');

        var key = $curr.data('tab-link');

        // Get tab, show, hide others.
        if (typeof $tabs[key] === 'undefined') {
            $tabs[key] = $('.content[data-tab="' + key + '"]');
        }

        $tabs[key].fadeIn();
        $tabs[key].siblings().hide();
    });

    $('.tabbs tr').click(function () {
        $('td:first > input[type="radio"]:first', $(this)).prop('checked', true);
    });
});
