<?php

/**
 * Features post type
 */
function features_post_type() {

	$labels = array(
		'name'                  => _x( 'Features', 'Post Type General Name', 'dmc' ),
		'singular_name'         => _x( 'Feature', 'Post Type Singular Name', 'dmc' ),
		'menu_name'             => __( 'Features', 'dmc' ),
		'name_admin_bar'        => __( 'Feature', 'dmc' ),
		'archives'              => __( 'Feature Archives', 'dmc' ),
		'attributes'            => __( 'Feature Attributes', 'dmc' ),
		'parent_item_colon'     => __( 'Parent Feature:', 'dmc' ),
		'all_items'             => __( 'All Features', 'dmc' ),
		'add_new_item'          => __( 'Add New Feature', 'dmc' ),
		'add_new'               => __( 'Add New', 'dmc' ),
		'new_item'              => __( 'New Feature', 'dmc' ),
		'edit_item'             => __( 'Edit Feature', 'dmc' ),
		'update_item'           => __( 'Update Feature', 'dmc' ),
		'view_item'             => __( 'View Feature', 'dmc' ),
		'view_items'            => __( 'View Features', 'dmc' ),
		'search_items'          => __( 'Search Feature', 'dmc' ),
		'not_found'             => __( 'Not found', 'dmc' ),
		'not_found_in_trash'    => __( 'Not found in Trash', 'dmc' ),
		'featured_image'        => __( 'Featured Image', 'dmc' ),
		'set_featured_image'    => __( 'Set featured image', 'dmc' ),
		'remove_featured_image' => __( 'Remove featured image', 'dmc' ),
		'use_featured_image'    => __( 'Use as featured image', 'dmc' ),
		'insert_into_item'      => __( 'Insert into Feature', 'dmc' ),
		'uploaded_to_this_item' => __( 'Uploaded to this Feature', 'dmc' ),
		'items_list'            => __( 'Features list', 'dmc' ),
		'items_list_navigation' => __( 'Features list navigation', 'dmc' ),
		'filter_items_list'     => __( 'Filter Features list', 'dmc' ),
    );

	$args = array(
		'label'                 => __( 'Feature', 'dmc' ),
		'description'           => __( 'DialMyCalls Features', 'dmc' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail', 'revisions', 'custom-fields' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-editor-ul',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'rewrite'				=> array( 'slug' => 'features' ),
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'feature', $args );

}
add_action( 'init', 'features_post_type', 0 );
