<?php

class Header_Desktop_Walker_Nav_Menu extends Walker_Nav_Menu {
    public function start_lvl( &$output, $depth = 0, $args = array() ) {
        $output .= '';
    }

    public function end_lvl( &$output, $depth = 0, $args = array() ) {
        $output .= '';
    }

    public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
        $classes = array();
        if( !empty( $item->classes ) ) {
            $classes = (array) $item->classes;
        }

        $active_class = '';
        if( in_array('current-menu-item', $classes) ) {
            $active_class = 'active ';
        } else if( in_array('current-menu-parent', $classes) ) {
            $active_class = 'active-parent ';
        } else if( in_array('current-menu-ancestor', $classes) ) {
            $active_class = 'active-ancestor ';
        }

		$has_children = false;
        if( in_array('menu-item-has-children', $classes) ) {
            $has_children = true;
		}

		$has_parent = false;
        if( $item->menu_item_parent ) {
            $has_parent = true;
        }

        $url = '';
        if( !empty( $item->url ) ) {
            $url = $item->url;
        }

		if ( $has_children ) {
			$output .= '<div class="dropdown link pull-left">';
			$output .= '<a class="' . $active_class . 'dropdown-toggle"  data-toggle="dropdown"  href="' . $url . '">' . $item->title . '&nbsp;<b class="caret"></b></a><ul class="dropdown-menu">';
		} else if ( $has_parent ) {
			$output .= '<li><a class="' . $active_class . '" href="' . $url . '">' . $item->title . '</a>';
		} else {
			$output .= '<div class="link pull-left"><a class="' . $active_class . '" href="' . $url . '">' . $item->title . '</a>';
		}

    }

    public function end_el( &$output, $item, $depth = 0, $args = array() ) {

		$classes = array();
        if( !empty( $item->classes ) ) {
            $classes = (array) $item->classes;
        }

		$has_children = false;
        if( in_array( 'menu-item-has-children', $classes ) ) {
            $output .= '</ul>';
		}

		$has_parent = false;
        if( $item->menu_item_parent ) {
            $has_parent = true;
        }

		if ( $has_parent ) {
			$output .= '</li>';
		} else {
			$output .= '</div>';
		}

    }
}

class Features_Walker_Nav_Menu extends Walker_Nav_Menu {
    public function start_lvl( &$output, $depth = 0, $args = array() ) {
        $output .= '<ul>';
    }

    public function end_lvl( &$output, $depth = 0, $args = array() ) {
        $output .= '</ul>';
    }

    public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
        $classes = array();
        if( !empty( $item->classes ) ) {
            $classes = (array) $item->classes;
        }

        $active_class = '';
        if( in_array('current-menu-item', $classes) ) {
            $active_class = ' class="active" ';
        } else if( in_array('current-menu-parent', $classes) ) {
            $active_class = ' class="active-parent" ';
        } else if( in_array('current-menu-ancestor', $classes) ) {
            $active_class = ' class="active-ancestor" ';
        }

		$has_children = false;
        if( in_array('menu-item-has-children', $classes) ) {
            $has_children = true;
		}

        $url = '';
        if( !empty( $item->url ) ) {
            $url = $item->url;
        }

		if ( $has_children ) {
			$output .= '<span>' . $item->title . '</span>';
		} else {
			$output .= '<li' . $active_class . '><a href="' . $url . '">' . $item->title . '</a>';
		}

    }

    public function end_el( &$output, $item, $depth = 0, $args = array() ) {
        $output .= '</li>';
    }
}
