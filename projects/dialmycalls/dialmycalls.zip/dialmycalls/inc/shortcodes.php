<?php

/**
 * Shortcode for printing social icons
 *
 * @param array @args User defined shortcode data
 */
function dmc_social_shortcode( $args ) {
    $output = '';

    if ( have_rows( 'social_profiles', 'option' ) ) {
        $output .= '<div class="social-profiles">';

        while ( have_rows( 'social_profiles', 'option' ) ) {
            the_row();

            $output .= '<a href="' . get_sub_field( 'url' ) . '" target="_blank">';
            $output .= '<img src="' . get_template_directory_uri() . '/assets/images/social-' . strtolower( get_sub_field( 'network' )['label'] ) . '.png" alt="DialMyCalls - ' . get_sub_field( 'network' )['label'] . '"></a>';
        }

        $output .= '</div>';
    }

    return $output;
}

/**
 * Printing Features sidebar menu with custom Nav Walker
 *
 * @param array @args User defined shortcode data
 */
function dmc_features_menu_shortcode( $args ) {
    $output = '';

    $output = wp_nav_menu( array(
        'theme_location'  => 'features',
        'walker'          => new Features_Walker_Nav_Menu(),
        'echo'            => false,
        'container'       => 'div',
        'container_class' => 'features-menu',
        'items_wrap'      => '%3$s'
    ) );

    return $output;
}

add_shortcode( 'dmc_social', 'dmc_social_shortcode' );
add_shortcode( 'dmc_features_menu', 'dmc_features_menu_shortcode' );
