<?php
/**
 * Register widgetized areas.
 *
 */
function dmc_widgets_init() {

	// Footer widgets
	$widgets = array(
		'feature-left' => array(
			'name' => 'Feature Left',
			'classes' => 'widget',
			'before_title' => '<h3>',
			'after_title' => '</h3>'
		),
		'footer-1' => array(
			'name' => 'Footer 1',
			'classes' => 'span3 widget',
			'before_title' => '<h4>',
			'after_title' => '</h4>'
		),
		'footer-2' => array(
			'name' => 'Footer 2',
			'classes' => 'span3 widget',
			'before_title' => '<h4>',
			'after_title' => '</h4>'
		),
		'footer-3' => array(
			'name' => 'Footer 3',
			'classes' => 'span3 widget',
			'before_title' => '<h4>',
			'after_title' => '</h4>'
		),
		'footer-4' => array(
			'name' => 'Footer 4',
			'classes' => 'span3 widget',
			'before_title' => '<h4>',
			'after_title' => '</h4>'
		),
	);

	foreach ( $widgets as $id => $value ) {
		register_sidebar( array(
			'name'          => $value['name'],
			'id'            => $id,
			'before_widget' => '<div class="' . $value['classes'] . '">',
			'after_widget'  => '</div>',
			'before_title'  => $value['before_title'],
			'after_title'   => $value['after_title'],
		) );
	}

}
add_action( 'widgets_init', 'dmc_widgets_init' );
