<?php
/**
 * Template for frontpage
 *
 * @since 1.0
 */

    get_header();
?>
<article class="container">

    <div id="content">

        <!-- / .breadcrumbs -->
        <?php
            if ( function_exists('yoast_breadcrumb') ) {
                yoast_breadcrumb('<span id="breadcrumb">','</span>');
            }
        ?>
        <!-- <span style="margin:25px;">
            <a href="http://www.dialmycalls.com/index.html">Home</a> &gt;
            <a href="http://www.dialmycalls.com/features.html">Features</a> &gt; 2-Way Text Messaging
        </span> -->
        <!-- / .end breadcrumbs -->

        <div class="container-fluid">

            <div class="row-fluid">
                <?php get_sidebar( 'feature' ); ?>

                <div class="span9">

                    <section id="main">

                        <div class="hentry page">

                            <div class="the-content">
                                <?php the_content(); ?>
                            </div>
                            <!-- / .the-content -->

                        </div>
                        <!-- / .hentry page -->

                        <section id="call-to">
                            <p style="padding-top:20px;">Create An Account Today And See Why 1,000s Of People Rely On Us</p>
                            <p class="button">
                                <a href="http://www.dialmycalls.com/signup.html">Try Out DialMyCalls Now For Free</a>
                            </p>

                        </section>
                    </section>
                    <!-- #main -->

                </div>

            </div>

        </div>
        <!-- container-fluid -->


    </div>
    <!-- .content -->

</article>
<!-- .container -->

<?php get_footer(); ?>
