<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the section.content div and all content after.
 *
 * @since 1.0
 */
?>
    <footer id="footer">

        <div class="container">

            <div class="content-footer">
                <form class="form-search account signupForm" action="two-way-text-messaging.html#" method="post" id="shortSignupForm">
                    <input type="hidden" name="action" value="signup" />
                    <input type="hidden" name="skip_confirm_password" value="1" />
                    <input type="hidden" name="7a125fa788d7c9e2ba8b1852c5f5f3d0" value="2b60f0127cea2e507056af79b8f40c9c" />
                    <fieldset>

                        <label>Sign Up for a Free Basic Account</label>
                        <input type="email" class="input-medium search-query" placeholder="Your E-mail" name="email" autocomplete="off" required
                        />
                        <input type="password" class="input-medium search-query" placeholder="Create Password" name="password" autocomplete="off"
                            required />
                        <button type="submit" class="btn-large">Try It Free</button>

                    </fieldset>

                </form>

                <div class="row-fluid">

                    <?php
                        $footer_widgets = array( 'footer-1', 'footer-2', 'footer-3', 'footer-4' );

                        foreach ( $footer_widgets as $id ) {
                            if ( is_active_sidebar( $id ) ) {
                                dynamic_sidebar( $id );
                            }
                        }
                    ?>

                </div>

            </div>

        </div>
        <!--/.container -->

        <div id="footerBottom">

            <div class="container">
                <p id="copyright">
                    <?php dmc_get_copyright( true ); ?>

                    <?php
                        $menu_params = array(
                            'theme_location'  => 'legal',
                            'container'       => false,
                            'after'           => ' <span>-</span> ',
                            'echo'            => false,
                            'items_wrap'      => '%3$s',
                            'depth'           => 0,
                        );

                        echo strip_tags( wp_nav_menu( $menu_params ), '<span><a>' );
                    ?>
                </p>

                <?php
                    $footer_logo_bg = get_field( 'footer_logo', 'option' ) ? ' style="background-image: url(' . get_field( 'footer_logo', 'option' ) . ');"' : '';
                ?>
                <h5<?php echo $footer_logo_bg; ?>>Dial My Calls</h5>

            </div>

        </div>

    </footer>
    <!-- /#footer -->

    <?php wp_footer(); ?>

</body>
</html>
