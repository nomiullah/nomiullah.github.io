$(window).load( function() {

		$('#mycalendar').monthly({
			mode: 'event',
			xmlUrl: 'events.xml'
		});
		        $('#myModal').modal('show');
 
	}); 
 
 var selector = '.content .view-option ul li a';

$(selector).on('click', function(e){
	e.preventDefault();
    $(selector).removeClass('active');
    $(this).addClass('active');
	$('.monthly-day-title-wrap').toggle();
	$('.monthly-day-wrap').toggle();
	$('.callender-agenda').toggle();
		
});
 
$('.content .view-option ul li a.agendaview').on('click', function(e){
	e.preventDefault();
    $(selector).removeClass('active');
    $(this).addClass('active');
	$('.monthly-day-title-wrap').hide();
	$('.monthly-day-wrap').hide();
	$('.callender-agenda').show();
		
});
$('.content .view-option ul li a.callenderview').on('click', function(e){
	e.preventDefault();
    $(selector).removeClass('active');
    $(this).addClass('active');
	$('.monthly-day-title-wrap').show();
	$('.monthly-day-wrap').show();
	$('.callender-agenda').hide();
		
});
 
 