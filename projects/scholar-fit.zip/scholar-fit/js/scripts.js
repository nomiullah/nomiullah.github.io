var $ = jQuery;

AOS.init();

$(document).on('scroll', function() {
    $(".floatit").css("bottom", Math.max(1 + 0.3*window.scrollY, 0) + "px");
})

 // Initialize Swiper
var swiper = new Swiper('.team .swiper-container', {
  effect: 'coverflow',
  grabCursor: false,
  centeredSlides: true,
  slidesPerView: '3',
  spaceBetween: -100,
  coverflowEffect: {
    rotate: 50,
    stretch: 0,
    depth: 100,
    modifier: 1,
    slideShadows : true,
  },
  navigation: {
    nextEl: '.team .swiper-button-next',
    prevEl: '.team .swiper-button-prev',
  },
  loop: true,
  breakpoints: {
        1300: {
          spaceBetween: -80,
        },
        1100: {
          spaceBetween: -80,
        },
        991: {
          spaceBetween: -60,
        },
        640: {
          spaceBetween: -50,
        },
        420: {
          spaceBetween: -40,
        }
  }
});

