﻿=== Site Master ===
Contributors: nomirajputTags: one-column, flexible-header, accessibility-ready, custom-colors, custom-menu, custom-logo, editor-style, featured-images, footer-widgets, rtl-language-support, sticky-post, threaded-comments, translation-ready
Requires at least: 4.9.6
Tested up to: WordPress 5.0
Requires PHP: 5.2.4
Stable tag: 1.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Our 2019 default theme is designed to show off the power of the block editor.

== Description: Our Site Master is designed to show off the power of the services. It features custom styles for all the default blocks, and is built so that what you see in the editor looks like what you'll see on your website. Requires at least: WordPress 4.9.6 Version: 1 License: GNU General Public License v2 or later License URI: LICENSE Text Domain: sitemaster Tags: one-column, flexible-header, accessibility-ready, custom-colors, custom-menu, custom-logo, editor-style, featured-images, footer-widgets, rtl-language-support, sticky-post, threaded-comments, translation-ready This theme, like WordPress, is licensed under the GPL. Use it to make something cool, have fun, and share what you've learned with others. Site Master is based on Underscores https://underscores.me/, (C) 2012-2018 Automattic, Inc.
Underscores is distributed under the terms of the GNU GPL v2 or later.